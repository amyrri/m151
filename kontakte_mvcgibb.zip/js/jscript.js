// JavaScript Document
function confdel() {
	answer=confirm("Wollen sie den Eintrag wirklich löschen?");
	return answer;
}
